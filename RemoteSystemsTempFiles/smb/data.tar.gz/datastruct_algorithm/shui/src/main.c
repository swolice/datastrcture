/*
 * main.c
 *
 *  Created on: 2016��7��4��
 *      Author: shuiting
 */

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {

	int i, j, k;
	int n = 100;

	while (n < 1000) {
		i = n / 100;
		j = n / 10 - i * 10;
		k = n % 10;

		if ((i * i * i + j * j * j + k * k * k) == n) {
			printf("shui=%d\n", n);
		}
		n++;
	}

	int count = 0;
	for (n = 1899; n < 2001; n++) {
		if (((n % 4 == 0) && (n % 100 != 0))
				|| ((n % 4 == 0) && (n % 400 == 0))) {
			printf("%d������\n", n);
			count++;
		}
	}
	printf("count=%d\n", count);

	return EXIT_SUCCESS;
}
