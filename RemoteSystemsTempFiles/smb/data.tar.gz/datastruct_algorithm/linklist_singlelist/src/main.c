/*
 * main.c
 *
 *  Created on: 2016��6��20��
 *      Author: shuiting
 */
#include <stdio.h>
#include <stdlib.h>
#include <malloc.h>
#include "linklist_singlelist.h"

int main(int argc, char *argv[])
{


	return EXIT_SUCCESS;
}

